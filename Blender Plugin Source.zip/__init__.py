import bpy
import os
from . import core
from . import ops
from . import ui

# TODO:
#   1. C++ Dll
#   2. 多人优化


bl_info = {
    "name" : "MOTION STUDIO MOCAP",
    "author" : "Hengzhuo",
    "description" : "HengZhuo™ Lite Motion Studio ®️ 2024-2025",
    "blender" : (4, 0, 0),
    "version" : (0, 8, 26),
    "location" : "",
    "warning" : "",
    "doc_url" : "https://workspace.dingtalk.com/uVrUL3YtKmyhzgp1S7PE9r",
    "tracker_url" : "https://www.mostech.asia/#/",
    "category" : "MS"
}

class_list = [
    core.BoneRemapConfig,
    ops.MocapConnect,
    ops.MocapDisconnect,
    ops.MocapPlayButtonOperator,
    ops.MocapPauseButtonOperator,
    ops.MocapRecordButtonOperator,
    ops.MocapStopButtonOperator,
    ops.MocapCheckUpdateButtonOperator,
    ops.UpdatePromptOperator,
    ops.DownloadUpdateOperator,
    ops.InstallPromptOperator,
    ops.MocapActorNameBtnOperator,
    ops.MocapActorsVisibleOperator,
    ops.MocapActorsPoseOperator,
    ops.MocapActorsRetargetOperator,
    ops.MocapActorVisBtnOperator,
    ops.MocapActorPoseBtnOperator,
    ops.MocapUpdateTargetBtnOperator,
    ops.MS_UL_Target_List,
    ops.MS_UL_Remap_Sheet,
    ops.MocapRetargetRemapBtnOperator,
    ops.MocapBuildRemapListBtnOperator,
    ops.MocapRemapUpdateBtnOperator,
    ops.MS_UL_Remap_Items,
    ui.ConnectionPanel,
    ui.ActorsPanel,
    ui.RetargetPanel,
    ui.AboutPanel
]
    
def register():
    for item in class_list:
        bpy.utils.register_class(item)
    msSettings = ops.MSSettings()
    msSettings.cur_Version = '.'.join([str(i) for i in bl_info["version"]])
    msSettings.add_preview("ms_link",os.path.join(os.path.dirname(__file__),"icons", "Link.svg"))
    msSettings.add_preview("ms_unlink",os.path.join(os.path.dirname(__file__),"icons", "Unlink.svg"))
    msSettings.add_preview("ms_play",os.path.join(os.path.dirname(__file__),"icons", "Play.svg"))
    msSettings.add_preview("ms_pause",os.path.join(os.path.dirname(__file__),"icons", "Pause.svg"))
    msSettings.add_preview("ms_rec",os.path.join(os.path.dirname(__file__),"icons", "Rec.svg"))
    msSettings.add_preview("ms_stoprec",os.path.join(os.path.dirname(__file__),"icons", "StopRec.svg"))
    msSettings.add_preview("ms_logo",os.path.join(os.path.dirname(__file__),"icons", "motionstudiologo_nobg.png"))
    core.register_properties()
    
def unregister():
    msSettings = ops.MSSettings()
    msSettings.clear_preview()

    for item in class_list:
        bpy.utils.unregister_class(item)
    core.unregister_properties()
