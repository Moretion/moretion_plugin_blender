import bpy

class ActorsPanel(bpy.types.Panel):
    bl_idname = 'MS_MOCAP_PT_ActorsPanel'
    bl_label = '角色设置'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MS MOCAP"

    @classmethod
    def poll(cls, ctx):
        return ctx.scene.msm_connected

    def draw(self, ctx):
        layout = self.layout
        grid = layout.grid_flow(row_major=True, columns=4, align=True,even_columns=False)
        
        col1 = grid.column()
        col1.ui_units_x = 1
        col1.label(text="#")

        col2 = grid.column()
        col2.ui_units_x = 7
        col2.alignment='CENTER'
        col2.operator("ms_mocap.btn_actorname",text="角色名称" if ctx.scene.msm_show_actor_name else "角色ID")

        col3 = grid.column()
        col3.operator("ms_mocap.btn_actorvis_all",text='',icon='HIDE_OFF' if ctx.scene.msm_actor_visible else 'HIDE_ON',emboss=False)
        col3.ui_units_x = 1
        col3.alignment= 'CENTER'

        col4 = grid.column()
        col4.operator("ms_mocap.btn_actorpose_all",text='',icon='ARMATURE_DATA' if ctx.scene.msm_actor_pose else 'POSE_HLT',emboss=False)
        col4.ui_units_x = 1
        col4.alignment= 'CENTER'

        if ctx.scene.msm_actor_count == 0:
            row = layout.row()
            row.alignment='CENTER'
            row.label(text="无角色数据")
        else:
            for i in range(ctx.scene.msm_actor_count):
                col1.label(text=f"{i+1}")
                col2.label(text=getattr(ctx.scene, f"msm_actor_name_{i+1}" if ctx.scene.msm_show_actor_name else f"msm_actor_id_{i+1}"))
                col3.operator(f"ms_mocap.btn_actorvis", text="",emboss=False, icon='HIDE_OFF' if getattr(ctx.scene, f"msm_actor_vis_{i+1}") else 'HIDE_ON').click_index = i
                col4.operator(f"ms_mocap.btn_actorpose",text='',emboss=False, icon='ARMATURE_DATA' if getattr(ctx.scene, f"msm_actor_pose_{i+1}") else 'POSE_HLT').click_index = i