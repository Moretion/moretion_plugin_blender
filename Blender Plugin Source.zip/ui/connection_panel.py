import bpy
from ..ops.ms_settings import MSSettings

class ConnectionPanel(bpy.types.Panel):
    bl_idname = 'MS_MOCAP_PT_ConnectionPanel'
    bl_label = '连接设置'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MS MOCAP"

    def draw(self, ctx):
        msSettings = MSSettings()
        layout = self.layout
        box = layout.box()
        grid = box.grid_flow(row_major=True, columns=3, align=False,even_columns=False)
        col1 = grid.column()
        col1.ui_units_x = 3
        col1.prop(ctx.scene, 'msm_protocol',expand=True)
        col1.alignment='CENTER'
        col2 = grid.column()
        col2.ui_units_x = 3
        if ctx.scene.msm_protocol == 'TCP':
            col2.label(text = 'MS 地址')
            col2.label(text = 'MS 端口')
            
        else:
            col2.label(text = '本机地址')
            col2.label(text = '本机端口')
            
        col3 = grid.column()
        col3.ui_units_x = 6
        if ctx.scene.msm_protocol == 'TCP':
            col3.prop(ctx.scene, 'msm_msip', text = '')
            col3.prop(ctx.scene, 'msm_msport', text = '')
        else:
            col3.prop(ctx.scene, 'msm_local_ip', text = '')
            col3.prop(ctx.scene, 'msm_local_port', text = '')

        row = layout.row()
        if not ctx.scene.msm_connected:
            row.operator('ms_mocap.connect',text = '连接', icon_value=msSettings.get_icon_id('ms_link'))
            row.operator("ms_mocap.btn_play", text="同步",icon_value=msSettings.get_icon_id('ms_play'))
            row.operator("ms_mocap.btn_record", text="录制",icon_value=msSettings.get_icon_id('ms_rec'))
        else:
            row.operator('ms_mocap.disconnect',text='断开', icon_value=msSettings.get_icon_id('ms_unlink'))
            if not ctx.scene.msm_playing:
                row.operator("ms_mocap.btn_play", text="同步",icon_value=msSettings.get_icon_id('ms_play'))
                row.operator("ms_mocap.btn_record", text="录制",icon_value=msSettings.get_icon_id('ms_rec'))
            else:
                row.operator("ms_mocap.btn_pause", text="暂停",icon_value=msSettings.get_icon_id('ms_pause'))
                if ctx.scene.msm_recording:
                    row.operator("ms_mocap.btn_stop", text="结束",icon_value=msSettings.get_icon_id('ms_stoprec'))
                else:
                    row.operator("ms_mocap.btn_record", text="录制",icon_value=msSettings.get_icon_id('ms_rec'))


