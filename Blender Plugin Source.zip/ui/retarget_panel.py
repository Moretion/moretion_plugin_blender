import bpy
from ..ops.ms_connection import ActorMgr
actormgr = ActorMgr()

class RetargetPanel(bpy.types.Panel):
    bl_idname = 'MS_MOCAP_PT_RetargetPanel'
    bl_label = '重定向设置'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MS MOCAP"

    @classmethod
    def poll(cls, ctx):
        return ctx.scene.msm_connected

    def draw(self, ctx):
        layout = self.layout
        grid = layout.grid_flow(row_major=True, columns=2, align=False,even_columns=False)
        col1 = grid.column()
        col1.alignment='CENTER'
        col1.ui_units_x = 1
        col1.label(text = '源角色')
        col2 = grid.column()
        col2.ui_units_x = 3
        col2.prop(ctx.scene, 'msm_actor_source_ids',text="")

        if ctx.scene.msm_actor_source_ids != "NONE":
            row = layout.row()
            row.label(text = '候选重定向角色')
            row.label(text = '重定向目标角色')

            row = layout.row()
            col1 = row.column()
            col1.prop(ctx.scene, "msm_new_target",expand=True)
            col2 = row.column()
            col2.operator("ms_mocap.update_target_object", text="", icon='RIGHTARROW').action_add = True
            col2.operator("ms_mocap.update_target_object", text="", icon='TRASH').action_add = False
            col3 = row.column()
            col3.template_list(listtype_name="MS_UL_Target_List", list_id="target_list", dataptr=ctx.scene, propname="target_items", active_dataptr=ctx.scene, active_propname="target_active_index",rows=2)
            # col3.prop(ctx.scene,"target_items",expand=True,index=0)
            if ctx.scene.target_items_enums != "NONE":
                layout.operator("ms_mocap.build_remap",icon='CONSTRAINT_BONE')
                ac = actormgr.GetActor(ctx.scene.msm_actor_source_ids)
                if ac and ac.GetRemapList(ctx.scene.target_items_enums):
                    row = layout.row()
                    row.label(text=f"源骨骼 {ctx.scene.msm_actor_source_ids}")
                    row.label(text=f"目标骨骼 {ctx.scene.target_items_enums}")
                    layout.template_list(listtype_name="MS_UL_Remap_Items", list_id="remap_list", dataptr=ctx.scene, propname="bones_remap", active_dataptr=ctx.scene, active_propname="remap_active_index",rows=2)
                    row = layout.row()
                    row.label(text=ctx.scene.bones_remap[ctx.scene.remap_active_index].source_bone+':' )
                    row.prop_search(ctx.scene.bones_remap[ctx.scene.remap_active_index], 'name', bpy.data.armatures[ctx.scene.target_items_enums], 'bones', text='')
                    # row.operator("arp.pick_object", text="", icon='EYEDROPPER').action = 'pick_bone'
                    # layout.prop(ctx.scene, "remap_items_enums",text='选择骨骼')
                    layout.operator("ms_mocap.retarget_remap",icon='FILE')
            