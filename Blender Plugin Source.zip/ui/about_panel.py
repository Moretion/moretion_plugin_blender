import bpy
from ..ops.ms_settings import MSSettings

class AboutPanel(bpy.types.Panel):
    bl_idname = 'MS_MOCAP_PT_AboutPanel'
    bl_label = '关于插件'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MS MOCAP"
    
    msSettings = MSSettings()

    def draw(self, ctx):
        layout = self.layout
        
        row = layout.row()
        row.template_icon(icon_value=self.msSettings.get_icon_id('ms_logo'), scale=2)
        row.ui_units_x=6
        # row.scale_y=0.8
        col = row.column()
        col.ui_units_x = 8
        col.label(text=f"v{self.msSettings.cur_Version} | MS v{self.msSettings.MS_Version}")
        col.label(text=f"杭州魔讯®️版权所有©️24-25")
        row = layout.row()
        row.operator("wm.url_open", text="官网",icon='HOME').url = "https://www.mostech.asia/#/"
        row.operator("wm.url_open", text="指南",icon='HELP').url = "https://workspace.dingtalk.com/uVrUL3YtKmyhzgp1S7PE9r"
        row.operator("ms_mocap.btn_checkupdate", text="更新",icon='FILE_REFRESH')
        