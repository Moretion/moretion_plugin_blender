import bpy
import socket
from ..ops.ms_connection import ActorMgr

def get_local_ip():
    ip = "127.0.0.1"
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # 连接到一个公网地址，实际上不会发送任何数据
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"  # 无法获取时返回本地回环
    finally:
        s.close()
    return ip

actormgr = ActorMgr()

target_actors_enum = [('NONE', "None", "No objects available")]

def get_source_actor_ids(self, context):
    """
    获取当前角色列表中的角色ID列表，用于更新到源角色的下拉框列表中
    """
    if actormgr.Count()>0:
        return actormgr.actorIds
    return [('NONE', "None", "No objects available")]

def update_source_selected(self,context):
    """ 当切换 角色源时执行
    """
    print(f'update_source_selected: {bpy.context.scene.msm_actor_source_ids}')
    get_new_target_objs(None,None)
    get_target_acotrs(None,None)
    actormgr.RefreshRetargetEnumList()
    update_remap()

def get_new_target_objs(self,context):
    """
    获取当前场景中的具有骨骼的物体，并更新到新增目标的下拉框列表中
    """
    res = []
    index = 0
    names = actormgr.GetActorIDList()
    for obj in bpy.data.armatures:
        if obj.name not in names:
            res.append((obj.name,obj.name,"",index))
            index+=1
    if index>0:
        return res
    else:
        return [('NONE', "None", "No objects available")]
        
def update_new_target_objs(self,context):
    """
    当切换 新增目标角色时，暂时仅作为输出使用，点击增加按钮时，将选择的目标角色添加到当前选择的源角色中
    """
    print(f'update_new_target_rig: {bpy.context.scene.msm_new_target}')

def get_target_acotrs_enum(self, context):
    """
    获取当前源角色的目标角色列表，并更新到目标列表中
    """
    
    if bpy.context.scene.msm_actor_source_ids != "NONE":
        ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
        if ac:
            # bpy.context.scene.target_items.clear()
            # for n in ac.GetRetargetList():
            #     item = bpy.context.scene.target_items.add()
            #     item.name = n
            return ac.GetRetargetEnumList()
    return [('NONE', "None", "No objects available")]

def get_target_acotrs(self, context):
    """
    获取当前源角色的目标角色列表，并更新到目标列表中
    """
    print("get_target_acotrs")
    ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
    if ac:
        bpy.context.scene.target_items.clear()
        # bpy.context.scene.target_items_enums.clear()
        for n in ac.GetRetargetList():
            item = bpy.context.scene.target_items.add()
            item.name = n
    #     return ac.GetRetargetEnumList()
    # return [('NONE', "None", "No objects available")]

def update_target_selected(self,context):
    print(f'update_target_selected: {bpy.context.scene.target_items_enums}')
    for i, a in enumerate(bpy.data.armatures):
        print(f'{i} {a.name}')
    print("-------------^armatures^---------------")

    # print(f'{bpy.data.objects[bpy.context.scene.target_items_enums]}')
    # print(f'armatures: {bpy.data.armatures[bpy.context.scene.target_items_enums].name}')
    # print(f'{bpy.data.objects[bpy.context.scene.target_items_enums].name}')
    # get_target_rigs(None,None)

def update_remap():
    ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
    if ac:
        remaplist = ac.GetRemapList(bpy.context.scene.target_items_enums)
        bpy.context.scene.bones_remap.clear()
        for index,i in enumerate(ac.bones):
            remapitem = bpy.context.scene.bones_remap.add()
            remapitem.source_bone = i.name.replace(f'MS_{ac.deviceId}_','')
            if remaplist and remaplist['remap'][index]:
                remapitem.name = remaplist['remap'][index].name
            else:
                remapitem.name = "None"
            print(f"UR {index} T:{remapitem.name} S:{remapitem.source_bone}")

def get_remap_items_enum(self,context):
    ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
    if ac:
        remaplist = ac.GetRemapList(bpy.context.scene.target_items_enums)
        if remaplist:
            res = []
            for i,b in enumerate(remaplist['origin']): 
                res.append((b.name,b.name,"",i))
            return res
        return [('NONE', "None", "No objects available")]

def update_remap_items_selected(self,context):
    pass

class BoneRemapConfig(bpy.types.PropertyGroup):
    # implicit "name" property = target bone
    name: bpy.props.StringProperty(default='', description="Source Bone Name")
    source_bone : bpy.props.StringProperty(default='', description="Source Bone Name")
    id : bpy.props.IntProperty()

def register_properties():
    bpy.types.Scene.msm_protocol = bpy.props.EnumProperty(
        name = '连接协议',
        items = [('TCP', 'TCP', '', 1), ('UDP', 'UDP', '', 2)], 
        default = 'TCP'
    )

    bpy.types.Scene.msm_msip = bpy.props.StringProperty(
        name = 'MS端IP地址', 
        default = get_local_ip()
    )

    bpy.types.Scene.msm_msport = bpy.props.IntProperty(
        name = 'MS端IP端口',
        default = 9999,
        max = 65535,
        min = 0
    )

    bpy.types.Scene.msm_local_ip = bpy.props.StringProperty(
        name = '本机IP地址', 
        default = get_local_ip()
    )

    bpy.types.Scene.msm_local_port = bpy.props.IntProperty(
        name = '本机IP端口',
        default = 8888,
        max = 65535,
        min = 0
    )

    bpy.types.Scene.msm_connected = bpy.props.BoolProperty(
        name = '连接状态',
        default = False
    )
    bpy.types.Scene.msm_playing = bpy.props.BoolProperty(
        name = '同步状态',
        default = False
    )
    bpy.types.Scene.msm_recording = bpy.props.BoolProperty(
        name = '录制状态',
        default = False
    )

    # 角色设置区域

    bpy.types.Scene.msm_show_actor_name = bpy.props.BoolProperty(
        name = '显示角色名称',
        default = True
    )
    bpy.types.Scene.msm_actor_visible = bpy.props.BoolProperty(
        name = '显示隐藏角色',
        default = True
    )
    bpy.types.Scene.msm_actor_pose = bpy.props.BoolProperty(
        name = '角色姿态',
        default = True
    )
    bpy.types.Scene.msm_actor_count = bpy.props.IntProperty(
        name = '角色数量',
        default = 0,
        max = 5,
        min = 0
    )
    for i in range(5):  # Adding dynamic properties for rows
        setattr(bpy.types.Scene, f"msm_actor_name_{i+1}",
                bpy.props.StringProperty(name=f"角色 {i+1}", default=f"角色 {i+1}"))
        setattr(bpy.types.Scene, f"msm_actor_id_{i+1}",
                bpy.props.StringProperty(name=f"角色ID {i+1}", default=f"角色ID {i+1}"))
        setattr(bpy.types.Scene, f"msm_actor_vis_{i+1}",
                bpy.props.BoolProperty(name=f"角色显示 {i+1}", 
                                       default =True))
        setattr(bpy.types.Scene, f"msm_actor_pose_{i+1}",
                bpy.props.BoolProperty(name=f"角色姿态 {i+1}", 
                                       default = True))
    

    # 重定向设置区

    bpy.types.Scene.msm_actor_source_ids = bpy.props.EnumProperty(
        name = '源角色ID',
        items = get_source_actor_ids, 
        default=None,
        update = update_source_selected,
        description="选择要设置的源角色"
    )
    
    bpy.types.Scene.msm_new_target = bpy.props.EnumProperty(
        name = "新增目标角色", 
        default=None, 
        items = get_new_target_objs, 
        description="选择要增加的目标角色", 
        update=update_new_target_objs
    )
    
    # bpy.types.Scene.target_items = bpy.props.EnumProperty(
    #     name = '目标角色',
    #     default=None,
    #     items = get_target_acotrs, 
    #     description="选择要设置映射的目标角色", 
    #     update = update_target_selected
    # )
    bpy.types.Scene.target_items = bpy.props.CollectionProperty(
        type=bpy.types.PropertyGroup,
        name = '目标角色',
        description="选择要设置映射的目标角色"
    )

    bpy.types.Scene.target_items_enums = bpy.props.EnumProperty(
        name = '目标角色',
        default=None,
        items = get_target_acotrs_enum, 
        description="选择要设置映射的目标角色", 
        update = update_target_selected
    )
    bpy.types.Scene.target_active_index = bpy.props.IntProperty(
        name="Active Index", 
        default=0
    )

    bpy.types.Scene.bones_remap = bpy.props.CollectionProperty(
        type=BoneRemapConfig,
        name = '映射骨骼',
        description="选择要设置映射的目标角色的骨骼"
    )
    
    bpy.types.Scene.remap_active_index = bpy.props.IntProperty(
        name="Active Index", 
        default=0
    )
    bpy.types.Scene.remap_items_enums = bpy.props.EnumProperty(
        name = '映射骨骼',
        default=None,
        items = get_remap_items_enum, 
        update = update_remap_items_selected,
        description="选择要设置映射的目标角色的骨骼"
    )

    
def unregister_properties():
    delattr(bpy.types.Scene, "msm_protocol")
    delattr(bpy.types.Scene, "msm_msip")
    delattr(bpy.types.Scene, "msm_msport")
    delattr(bpy.types.Scene, "msm_local_ip")
    delattr(bpy.types.Scene, "msm_local_port")
    delattr(bpy.types.Scene, "msm_connected")
    delattr(bpy.types.Scene, "msm_playing")
    delattr(bpy.types.Scene, "msm_recording")
    delattr(bpy.types.Scene, "msm_show_actor_name")
    delattr(bpy.types.Scene, "msm_actor_visible")
    delattr(bpy.types.Scene, "msm_actor_pose")
    delattr(bpy.types.Scene, "msm_actor_count")

    delattr(bpy.types.Scene, "msm_actor_source_ids")
    delattr(bpy.types.Scene, "msm_new_target")
    delattr(bpy.types.Scene, "target_items")
    delattr(bpy.types.Scene, "target_active_index")
    delattr(bpy.types.Scene, "target_items_enums")

    delattr(bpy.types.Scene, "remap_active_index")
    delattr(bpy.types.Scene, "remap_items_enums")
    delattr(bpy.types.Scene, "bones_remap")
    for i in range(5):
        delattr(bpy.types.Scene, f"msm_actor_name_{i+1}")
        delattr(bpy.types.Scene, f"msm_actor_id_{i+1}")
        delattr(bpy.types.Scene, f"msm_actor_vis_{i+1}")
        delattr(bpy.types.Scene, f"msm_actor_pose_{i+1}")
