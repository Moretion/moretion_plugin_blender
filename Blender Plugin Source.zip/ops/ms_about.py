import bpy
from ..ops.ms_settings import MSSettings
import os
import requests

def is_new_version( latest_version, current_version):
    # 比较版本号
    return tuple(map(int, latest_version.split('.'))) > tuple(map(int, current_version.split('.')))

class MocapCheckUpdateButtonOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_checkupdate"
    bl_label = "检查更新"

    update_url = "https://gitee.com/felixfei91/MotionStudioPlugs/raw/master/update.json"

    def execute(self, context):
        msSettings = MSSettings()
        try:
            # 获取最新版本信息
            response = requests.get(self.update_url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                latest_version = data.get("blender")
                current_version = msSettings.cur_Version

                bpy.ops.wm.update_prompt('INVOKE_DEFAULT', latest_version=latest_version,cur_Version=current_version)
            else:
                self.report({'ERROR'}, "检测最新插件版本失败！")
        except Exception as e:
            self.report({'ERROR'}, f"检测更新失败: {str(e)}")
        return {'FINISHED'}

# 更新提示对话框
class UpdatePromptOperator(bpy.types.Operator):
    bl_idname = "wm.update_prompt"
    bl_label = "检测到新版插件"

    latest_version: bpy.props.StringProperty()  # 用于存储最新版本号
    cur_Version : bpy.props.StringProperty()
    def execute(self, context):
        # 开始下载
        if is_new_version(self.latest_version, self.cur_Version):
            # 弹出更新提示框
            bpy.ops.wm.download_update('INVOKE_DEFAULT', latest_version=self.latest_version)
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def cancel(self,context):
        print("取消更新")

    def draw(self, context):
        layout = self.layout
        if is_new_version(self.latest_version, self.cur_Version):
            layout.label(text=f"检测到有新版本: {self.latest_version}, 当前版本：{self.cur_Version}")
            layout.label(text="是否立即下载并更新? 点击窗口外放弃更新")
        else:
            layout.label(text=f"当前版本已经是最新版 {self.latest_version}")
    
# 下载更新的操作
class DownloadUpdateOperator(bpy.types.Operator):
    bl_idname = "wm.download_update"
    bl_label = "下载更新"

    latest_version: bpy.props.StringProperty()  # 用于存储最新版本号
    def execute(self, context):
        # 下载 ZIP 文件
        download_url_template = "https://gitee.com/felixfei91/MotionStudioPlugs/releases/download/{version}_BL/MotionStudio_Blender_4_Win64_v{version}.zip"
        download_url = download_url_template.format(version=self.latest_version)
        download_folder = os.path.expanduser("~/Downloads")
        self.zip_path = os.path.join(download_folder, f"MotionStudio_v{self.latest_version}.zip")

        try:
            response = requests.get(download_url, stream=True, timeout=30)
            with open(self.zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:
                        f.write(chunk)

            # 弹出下载完成对话框
            bpy.ops.wm.install_prompt('INVOKE_DEFAULT', zip_path=self.zip_path)
        except Exception as e:
            print(f"插件下载失败: {str(e)}")
            # self.report({'ERROR'}, f"Download failed: {str(e)}")

        return {'FINISHED'}
    
# 安装提示对话框
class InstallPromptOperator(bpy.types.Operator):
    bl_idname = "wm.install_prompt"
    bl_label = "新版插件下载完成"

    zip_path: bpy.props.StringProperty()  # 存储 ZIP 文件路径

    def execute(self, context):
        # 解压并安装
        try:
            bpy.ops.preferences.addon_install(filepath=self.zip_path,overwrite=True)
            bpy.ops.preferences.addon_enable(module="motionstudio_mocap")
            self.report({'INFO'}, "插件安装成功!")
        except Exception as e:
            self.report({'ERROR'}, f"插件安装失败: {str(e)}")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def cancel(self,context):
        print("取消安装")

    def draw(self, context):
        layout = self.layout
        layout.label(text="新插件已经下载完成!")
        layout.label(text="是否立即更新插件?")