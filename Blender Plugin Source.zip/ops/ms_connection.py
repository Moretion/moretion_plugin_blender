import bpy
# from ..mocap_api.msnetwork import *
from .ms_settings import MSSettings
import os
import socket
import threading
import json
from mathutils import  Vector,Quaternion
import math
from threading import Lock

# 用于后台线程的数据队列
network_thread = None
received_messages = None
mocap_timer = None
is_connected = False
is_connecting = False
connecting_count = 0
stop_event = threading.Event()

MAX_SOCKET_BUFFER = 32000
# 使用列表推导式批量更新旋转
update_list = [
    (1, 'crotch'), (2, 'rightUpperLeg'), (3, 'rightLowerLeg'),
    (4, 'rightFoot'), (5, 'leftUpperLeg'), (6, 'leftLowerLeg'),
    (7, 'leftFoot'), (8, 'waistOne'), (9, 'waistTwo'),
    (10, 'back'), (13, 'head'), (14, 'rightShoulder'),
    (15, 'rightUpperArm'), (16, 'rightLowerArm'), (17, 'rightHand'),
    (18, 'rightThumbUnder'), (19, 'rightThumbMid'), (20, 'rightThumbUp'),
    (22, 'rightForeFingerUnder'), (23, 'rightForeFingerMid'),
    (24, 'rightForeFingerUp'), (26, 'rightMiddleFingerUnder'),
    (27, 'rightMiddleFingerMid'), (28, 'rightMiddleFingerUp'),
    (30, 'rightRingFingerUnder'), (31, 'rightRingFingerMid'),
    (32, 'rightRingFingerUp'), (34, 'rightLittleFingerUnder'),
    (35, 'rightLittleFingerMid'), (36, 'rightLittleFingerUp'),
    (37, 'leftShoulder'), (38, 'leftUpperArm'), (39, 'leftLowerArm'),
    (40, 'leftHand'), (41, 'leftThumbUnder'), (42, 'leftThumbMid'),
    (43, 'leftThumbUp'), (45, 'leftForeFingerUnder'),
    (46, 'leftForeFingerMid'), (47, 'leftForeFingerUp'),
    (49, 'leftMiddleFingerUnder'), (50, 'leftMiddleFingerMid'),
    (51, 'leftMiddleFingerUp'), (53, 'leftRingFingerUnder'),
    (54, 'leftRingFingerMid'), (55, 'leftRingFingerUp'),
    (57, 'leftLittleFingerUnder'), (58, 'leftLittleFingerMid'),
    (59, 'leftLittleFingerUp')
]

class Actor:
    # 使用 __slots__ 限制实例属性
    __slots__ = ('name', 'deviceId', 'index', 'visible', 'tPose', 
                 'isInitSuccess', 'scale_Trans', 'rotOrder', 'fbxImported',
                 'rec', 'start_time', 'bones', 'rootObj', 'recordData','recordRoot',
                 'world_to_local', 'deviceType', 'retarget_objs',
                 'retargetList', 'remap_dict', 'defaultHeight')

    def __init__(self,index:int,name:str,deviceId:str,deviceType:str):
        self.name = name
        self.deviceId = deviceId
        self.index = index
        self.visible = True
        self.tPose = False
        self.isInitSuccess = False
        self.scale_Trans = 100.0
        self.rotOrder = 'xyz'
        self.fbxImported = False
        self.rec = False
        self.start_time = None
        self.bones = list()
        self.rootObj = None
        self.recordData = list()
        self.recordRoot = list()
        self.world_to_local = None
        self.deviceType = True if deviceType == 'hand' else False # True: Hand False: Body or Assemble
        self.retarget_objs = list()
        self.retargetList =  [('NONE', "None", "No objects available")]
        self.remap_dict = dict()
        self.defaultHeight = 0
        setattr(bpy.types.Scene, f"msm_actor_name_{index+1}",name)
        setattr(bpy.types.Scene, f"msm_actor_id_{index+1}",deviceId)
        print(f"Create new Actor @ {index} {name} ID: {deviceId}")
        self.ImportFBX()

    def ImportFBX(self):
        bpy.ops.import_scene.fbx(filepath=os.path.join(os.path.dirname(__file__),"../fbx", "MS_Robot.fbx"),ignore_leaf_bones=True)

        print(f"ImportFBX {[a.name_full for a in bpy.data.armatures]}")

        for obj in bpy.context.selected_objects:
            if obj.type == 'ARMATURE':
                
                # 如果是骨骼对象，重命名
                obj.name = self.deviceId
                for i,b in enumerate(obj.pose.bones):
                    if i == 0:
                        b.name = f'MS_{self.deviceId}_Root'
                        
                        print(f'defaultY {self.defaultHeight}')
                    else:
                        if i==1:
                            self.defaultHeight = b.matrix_basis.translation[1]
                        b.name = b.name.replace('Motion',f'MS_{self.deviceId}')
                    # print(f'{i}  {b.name}')
                    self.bones.append(b)
                    self.recordData.append(list())
                self.rootObj = obj
                self.world_to_local = self.rootObj.matrix_world.inverted()
                obj.hide_set(True)  # 确保骨骼可见
            elif obj.type == 'MESH':
                # 如果是网格对象，按前缀重命名并隐藏
                obj.name = f"MSMesh_{self.deviceId}_{obj.name}"
                # print(obj.name)
                if self.deviceType:
                    if 'Hand' in obj.name:
                        obj.hide_set(False)
                    else:
                        obj.hide_set(True)
                        bpy.data.objects.remove(obj, do_unlink=True)
                else:
                    obj.hide_set(False)
            else:
                # 对其他类型的对象进行处理（如果需要）
                pass
        for a in bpy.data.armatures:
            if f'MS_{self.deviceId}_Root' == a.bones[0].name:
                a.name = self.deviceId
        bpy.context.view_layer.objects.active = obj
        # bpy.ops.object.mode_set(mode='EDIT')
        
        self.fbxImported = True

    def SetTPose(self,tpose=True):
        self.tPose = tpose

    def SetVisible(self,vis=True):
        if not self.fbxImported:
            self.ImportFBX()
        for obj in bpy.data.objects:
        # 判断对象是否属于指定角色
            if self.deviceId in obj.name and obj.type == 'MESH':
                if self.deviceType:
                    if 'Hand' in obj.name:
                        obj.hide_set(not vis)
                    else:
                        obj.hide_set(True)
                else:
                    obj.hide_set(not vis)

    def UpdateRot(self,index,data,roo='XYZ'):
        if self.tPose:
            euler = [0, 0, 0]
        else:
            euler = [math.radians(float(e)*0.5) for e in data]
            
        c = [math.cos(e) for e in euler]
        s = [math.sin(e) for e in euler]

        # 使用字典查找代替match语句,提高查找效率
        rot_dict = {
            'XYZ': lambda: (
                c[0] * c[1] * c[2] - s[0] * s[1] * s[2],
                s[0] * c[1] * c[2] + c[0] * s[1] * s[2], 
                c[0] * s[1] * c[2] - s[0] * c[1] * s[2],
                c[0] * c[1] * s[2] + s[0] * s[1] * c[2]
            ),
            'XZY': lambda: (
                c[0] * c[1] * c[2] + s[0] * s[1] * s[2],
                s[0] * c[1] * c[2] - c[0] * s[1] * s[2],
                c[0] * c[1] * s[2] - s[0] * s[1] * c[2], 
                c[0] * s[1] * c[2] + s[0] * c[1] * s[2]
            ),
            'ZXY': lambda: (
                c[0] * c[1] * c[2] - s[0] * s[1] * s[2],
                c[0] * s[1] * c[2] - s[0] * c[1] * s[2],
                c[0] * c[1] * s[2] + s[0] * s[1] * c[2],
                s[0] * c[1] * c[2] + c[0] * s[1] * s[2]
            ),
            'ZYX': lambda: (
                c[0] * c[1] * c[2] + s[0] * s[1] * s[2],
                c[0] * c[1] * s[2] - s[0] * s[1] * c[2],
                c[0] * s[1] * c[2] + s[0] * c[1] * s[2],
                s[0] * c[1] * c[2] - c[0] * s[1] * s[2]
            ),
            'YZX': lambda: (
                c[0] * c[1] * c[2] - s[0] * s[1] * s[2],
                c[0] * c[1] * s[2] + s[0] * s[1] * c[2],
                s[0] * c[1] * c[2] + c[0] * s[1] * s[2],
                c[0] * s[1] * c[2] - s[0] * c[1] * s[2]
            ),
            'YXZ': lambda: (
                c[0] * c[1] * c[2] + s[0] * s[1] * s[2],
                c[0] * s[1] * c[2] + s[0] * c[1] * s[2],
                s[0] * c[1] * c[2] - c[0] * s[1] * s[2],
                c[0] * c[1] * s[2] - s[0] * s[1] * c[2]
            )
        }

        # 直接获取四元数值
        w,x,y,z = rot_dict[roo]()
        
        # 一次性设置四元数
        quat = (w,x,y,z)
        self.bones[index].rotation_quaternion = quat
        
        # 优化遍历
        for t in self.remap_dict.values():
            if t['enable'] and t['remap'][index]:
                t['remap'][index].rotation_quaternion = quat

    def UpdatePos(self,index,data,mod=[0,0,0]):
        if self.tPose:
            loc = mod
        else:
            # 一次性计算位置
            loc = [float(d)*self.scale_Trans + m for d,m in zip(data,mod)]
        
        # 创建Vector对象
        loc_vector = Vector(loc)
        self.bones[index].matrix.translation = loc_vector
        
        # 优化遍历
        for t in self.remap_dict.values():
            if t['enable'] and t['remap'][index]:
                t['remap'][index].matrix.translation = loc_vector

    def UpdateLoc(self,coord,initcoord,mod=[0,0,0]):
        if self.tPose:
            loc = [0,0,0]
        else:
            # 一次性计算位置
            # loc = [float(c) + float(ic)+m for c,ic,m in zip(coord,initcoord,mod)]
            loc = [float(coord[0]) + float(initcoord[0]) + float(mod[0]),
                   float(coord[1]) + float(mod[1]),
                   float(coord[2]) + float(initcoord[2]) + float(mod[2])]
            # print(f"{self.deviceId[-5:]} Loc C [{float(coord[0]):.4f}, {float(coord[1]):.4f}, {float(coord[2]):.4f}]\n\tI [{float(initcoord[0]):.4f}, {float(initcoord[1]):.4f}, {float(initcoord[2]):.4f}]\n\tL [{loc[0]:.4f}, {loc[1]:.4f}, {loc[2]:.4f}]")
            
        # 创建Vector对象
        loc_vector = Vector((loc[0],-loc[2],loc[1]))
        bpy.data.objects[self.deviceId].location = loc_vector
        
        if self.rec:
            current_time = mocap_timer.time_delta
            self.recordRoot.append((current_time, loc_vector))
        # 优化遍历
        for t in self.remap_dict.values():
            if t['enable'] and t['obj']:
                t['obj'].location = loc_vector

    def Update(self,data):
        if not (self.rootObj and self.fbxImported and data['deviceId'] == self.deviceId and len(self.bones)>50):
            return
            
        roo = data['bvhRotationOrder']
        
        self.UpdateLoc(data['coordinate'],data['initCoordinate'],[0,-0.9,0])
        if self.deviceType: # Hand
            self.UpdatePos(17,data['rightHandCoordinate'],self.bones[16].matrix.translation)
            self.UpdatePos(40,data['leftHandCoordinate'],self.bones[39].matrix.translation)

        for idx, key in update_list:
            self.UpdateRot(idx, data[key], roo)
                
        if self.rec:
            # 优化记录数据
            current_time = mocap_timer.time_delta
            for i,b in enumerate(self.bones):
                self.recordData[i].append((current_time, Vector(b.location), Quaternion(b.rotation_quaternion)))

    def StartRec(self):
        if self.rec:
            return
        self.rec = True
        for rd in self.recordData:
            rd = list()
    
    def StopRec(self):
        if not self.rec:
            return
        self.rec = False
        self.rootObj.animation_data_create()
        action = bpy.data.actions.new(name='mocap')
        self.rootObj.animation_data.action = action
        dt = 1 / bpy.context.scene.render.fps
        
        root_data_path = 'location'
        print(f"Root Data Path: {root_data_path}")
        for axis_i in range(3):
            curve = action.fcurves.new(data_path = root_data_path, index = axis_i)
            keyframe_points = curve.keyframe_points
            frame_count = len(self.recordRoot)
            keyframe_points.add(frame_count)
            frame_time = 0
            for frame_i in range(frame_count):
                keyframe_points[frame_i].co = (
                    frame_time / dt + 1,
                    self.recordRoot[frame_i][1][axis_i]
                )
                frame_time = frame_time + self.recordRoot[frame_i][0]

        for i,b in enumerate(self.bones):
            bone_data = self.recordData[i]
            
            data_path = 'pose.bones["%s"].location' % b.name
            for axis_i in range(3):
                curve = action.fcurves.new(data_path = data_path, index = axis_i)
                keyframe_points = curve.keyframe_points
                frame_count = len(bone_data)
                keyframe_points.add(frame_count)
                frame_time = 0
                for frame_i in range(frame_count):
                    keyframe_points[frame_i].co = (
                        frame_time / dt + 1,
                        bone_data[frame_i][1][axis_i]
                    )
                    frame_time = frame_time + bone_data[frame_i][0]

            data_path = 'pose.bones["%s"].rotation_quaternion' % b.name
            for axis_i in range(4):
                curve = action.fcurves.new(data_path = data_path, index = axis_i)
                keyframe_points = curve.keyframe_points
                frame_count = len(bone_data)
                keyframe_points.add(frame_count)
                frame_time = 0
                for frame_i in range(frame_count):
                    keyframe_points[frame_i].co = (
                        frame_time / dt + 1,
                        bone_data[frame_i][2][axis_i]
                    )
                    frame_time = frame_time + bone_data[frame_i][0]

        for cu in action.fcurves:
            for bez in cu.keyframe_points:
                bez.interpolation = 'LINEAR'
    
    def AddRetarget(self,obj):
        for r in self.retarget_objs:
            if obj == r:
                return False
        print(f"{self.deviceId} Add {obj.name}")
        self.retarget_objs.append(obj)
        return True

    def RemoveRetarget(self,obj):
        print(f"{self.deviceId} Ready to Remove {obj.name}")
        if len(self.retarget_objs)>0:
            if obj in self.retarget_objs:
                self.retarget_objs.remove(obj)
                print(f"{self.deviceId} Removed {obj.name}")
        if obj.name in self.remap_dict.keys():
            print(f"self.remap_dict Removed {obj.name}")
            self.remap_dict.pop(obj.name)

    def GetRetargetList(self):
        # for i,r in enumerate(self.retarget_objs):
        #     print(f"{self.deviceId} [{i}] RetargetList: {r.name}")
        if len(self.retarget_objs)<=0:
            return []
        print("GetRetargetList")
        return [r.name for r in self.retarget_objs]
    
    def RefreshRetargetEnumList(self):
        if len(self.retarget_objs)<=0:
            self.retargetList =  [('NONE', "None", "No objects available")]
            return
        print("GetRetargetEnumList")
        self.retargetList = [(r.name,r.name,'',i) for i,r in enumerate(self.retarget_objs)]

    def GetRetargetEnumList(self):
        return self.retargetList

    def ClearRetarget(self):
        self.retarget_objs.clear()
        self.remap_dict.clear()

    def BuildNewRemapList(self,objName:str):
        print(f"\n{'Build New Remap':#^50}\n{self.deviceId} : {objName}\n")
        if objName not in self.remap_dict.keys():
            for o in self.retarget_objs:
                if o.name == objName:
                    self.remap_dict[objName] = {'enable':False,'remap':[],'origin':o.pose.bones,'obj':o}
                    for i,sourceBone in enumerate(self.bones):
                        settarget = False
                        sname = sourceBone.name.replace(f'MS_{self.deviceId}_','')
                        
                        for j,targetBone in enumerate(o.pose.bones):
                            if sname in targetBone.name:
                                self.remap_dict[objName]['remap'].append(targetBone)
                                settarget = True
                                # print(f"[{i:0>2}] {sourceBone.name} | {targetBone.name}")
                                break
                        if not settarget:
                            self.remap_dict[objName]['remap'].append(None)
                            # print(f"[{i:0>2}] {sourceBone.name} | not found {sname}")
    
    def GetRemapList(self,objName):
        if objName in self.remap_dict.keys():
            # print(f"GetRemapList {objName}")
            return self.remap_dict[objName]
        return None
    
    def SaveAndEnableRemapList(self,objName,bones_remap):
        if objName in self.remap_dict.keys():
            self.remap_dict[objName]['enable'] = True
            for i,b in enumerate(bones_remap):
                # print(f'{i} {b.source_bone} {b.name}')
                if b.name != 'None' and b.name !='':
                    ind = self.remap_dict[objName]['origin'].find(b.name)
                    # print(f'index at {ind}')
                    if ind >=0:
                        self.remap_dict[objName]['remap'][i] = self.remap_dict[objName]['origin'][ind]

class ActorMgr:
    _instance = None
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls, *args, **kwargs)
            cls._instance._lock = Lock()
            cls._instance.actors = []
            cls._instance.sync = True
            cls._instance.actorIds = []
        return cls._instance

    def Update(self,data):
        with self._lock:
            if not self.sync:
                return
            for d in data['deviceList']:
                actor_exist = False
                for a in self.actors:
                    if a.deviceId == d['deviceId']:
                        # print(d['deviceId'])
                        a.Update(d)
                        actor_exist = True
                if not actor_exist:
                    self.AddNewActor(d)
                    bpy.context.scene.msm_actor_count = len(self.actors)

    def AddNewActor(self,data):
        if 'deviceType' in data.keys():
            self.actors.append(Actor(len(self.actors),data['actorName'],data['deviceId'],data['deviceType']))
            self.actorIds.append((data['deviceId'],data['deviceId'],'',len(self.actors)-1))
        else:
            self.actors.append(Actor(len(self.actors),data['actorName'],data['deviceId'],'assemble'))
            self.actorIds.append((data['deviceId'],data['deviceId'],'',len(self.actors)-1))
        print(f'Add new Actor {data["deviceId"]}')
    
    def Count(self):
        return len(self.actors)
    
    def Clear(self):
        self.sync = False
        self.actors.clear()
        self.actorIds.clear()
        self.Remove_all_characters()
        bpy.context.scene.msm_actor_count = 0

    def GetActorIDList(self)->list:
        if self.Count()>0:
            return [a.deviceId for a in self.actors]
        return  []
    
    def GetActor(self,id)->Actor:
        if self.Count()>0:
            for a in self.actors:
                if a.deviceId == id:
                    return a
        return None

    def Remove_all_characters(self):
        # 获取所有骨架和网格对象
        objects_to_remove = [
            obj for obj in bpy.context.scene.objects
            if obj.type in {'ARMATURE', 'MESH'}
        ]

        # 删除对象
        for obj in objects_to_remove:
            # bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.data.objects.remove(obj, do_unlink=True)
            # bpy.ops.object.delete()
            # print(f"Deleted object: {obj.name}")
        bpy.context.view_layer.objects.active = None
        bpy.ops.object.select_all(action='DESELECT')
    
    def LiveSync(self,sync=True):
        self.sync = sync
        if not self.sync:
            self.StopRec()
    
    def SetTpose(self, tpose = True):
        for a in self.actors:
            a.SyncPose(tpose)

    def StartRec(self):
        for a in self.actors:
            a.StartRec()
    
    def StopRec(self):
        for a in self.actors:
            a.StopRec()

    def RefreshRetargetEnumList(self):
        for a in self.actors:
            a.RefreshRetargetEnumList()

    def AddRetargetToActor(self,actorId,targetObj):
        for a in self.actors:
            if a.deviceId == actorId:
                a.AddRetarget(targetObj)
            else:
                a.RemoveRetarget(targetObj)
    def RemoveRetargetFromActor(self,actorId,targetObj):
        for a in self.actors:
            if a.deviceId == actorId:
                a.RemoveRetarget(targetObj)
actor_mgr = ActorMgr()

# TCP 后台线程函数
def tcp_client(host, port,stop_event):
    global received_messages, is_connected,is_connecting
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.settimeout(2) 
            sock.connect((host, port))
            is_connected = True
            is_connecting = True
            while is_connected and not stop_event.is_set():
                try:
                    data = sock.recv(MAX_SOCKET_BUFFER)
                    # print(f'is_connected')
                    if data:
                        received_messages=data
                        is_connecting = False
                except BlockingIOError as e:
                    is_connected = False
                    is_connecting = False
                    print(f'BlockingIOError Error!: {e}')
        except Exception as e:
            print(f'Connection Error!: {e}')
        finally:
            is_connecting = False
            is_connected = False
            sock.close()

def udp_client(ip,port,stop_event):
    global received_messages, is_connected,is_connecting
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        try:
            sock.settimeout(2) 
            sock.bind((ip, port))
            is_connected = True
            is_connecting = True
            while is_connected and not stop_event.is_set():
                try:
                    data,_ = sock.recvfrom(MAX_SOCKET_BUFFER)
                    # print(f'is_connected')
                    if data:
                        received_messages=data
                        is_connecting = False
                except BlockingIOError as e:
                    is_connected = False
                    is_connecting = False
                    print(f'BlockingIOError Error!: {e}')
        except Exception as e:
            print(f'Connection Error!: {e}')
        finally:
            is_connecting = False
            is_connected = False
            sock.close()

def poll_data(ctx):
    global received_messages,actor_mgr
    if received_messages:
        try:
            jsonData = json.loads(received_messages)
            actor_mgr.Update(jsonData)
        except Exception as e:
            print(f'Json Error: {e}')

class MocapConnect(bpy.types.Operator):
    bl_idname = 'ms_mocap.connect'
    bl_label = 'Connect'

    def execute(self, ctx):
        self.report({'INFO'}, "Connect Clicked!")

        global network_thread,mocap_timer,is_connected,actor_mgr,is_connecting,connecting_count

        if  is_connected:
            self.report({"INFO"}, "Already connected!")
            return {"CANCELLED"}
        is_connecting = True
        connecting_count = 0
        # 启动后台线程
        if ctx.scene.msm_protocol == 'TCP':
            print("Using TCP!")
            host = ctx.scene.msm_msip
            port = ctx.scene.msm_msport
            network_thread = threading.Thread(target=tcp_client, args=(host, port,stop_event), daemon=True)
        else:
            print("Using UDP!")
            host = ctx.scene.msm_local_ip
            port = ctx.scene.msm_local_port
            network_thread = threading.Thread(target=udp_client, args=(host, port,stop_event), daemon=True)
        network_thread.start()
        
        ctx.window_manager.modal_handler_add(self)
        mocap_timer = ctx.window_manager.event_timer_add(1 / 60, window = ctx.window)
        # is_connected = True
        # is_connecting = False
        connecting_count = 0
        ctx.scene.msm_connected= True
        ctx.scene.msm_playing= True
        actor_mgr.sync = True
        print(f"Connecting... {host}:{port}")
        self.report({"INFO"}, f"Connecting... {host}:{port}")
        return {'RUNNING_MODAL'}

    def modal(self, ctx, evt):
        global connecting_count,is_connecting
        if is_connecting :
            connecting_count+=1
            if connecting_count> 100:
                print(f'Connect Count :{connecting_count}')
                self.cancel(ctx)
                return {'FINISHED'}
        # 如果断开连接，则停止
        elif not is_connected:
            self.cancel(ctx)
            return {'FINISHED'}
        if evt.type == 'TIMER':
            # 轮询数据
            poll_data(ctx)
        

        return {'PASS_THROUGH'}
    
    def cancel(self, ctx):
        """
        取消操作。
        """
        # 停止接收数据
        global mocap_timer,is_connected,actor_mgr,connecting_count,is_connecting,stop_event,received_messages
        ctx.window_manager.event_timer_remove(mocap_timer)
        is_connected = False
        is_connecting = False
        connecting_count = 0
        ctx.scene.msm_connected= False
        ctx.scene.msm_playing= False
        ctx.scene.msm_recording = False
        stop_event.set()
        if network_thread:
            network_thread.join()
        actor_mgr.Clear()

        ctx.scene.msm_actor_count = 0
        ctx.scene.msm_actor_source_ids = "NONE"
        # ctx.scene.msm_new_target = "NONE"
        arms = [a for a in bpy.data.armatures]
        for a in arms:
            bpy.data.armatures.remove(a)
        ctx.scene.target_items.clear()
        ctx.scene.target_items_enums="NONE"
        received_messages = None
        self.report({"INFO"}, "Cancel.... Disconnected.")
        stop_event.clear()
        return {'CANCELLED'}
    
class MocapDisconnect(bpy.types.Operator):
    bl_idname = 'ms_mocap.disconnect'
    bl_label = 'Disconnect'

    def execute(self, ctx):
        global mocap_timer,network_thread,is_connected,actor_mgr,stop_event,received_messages
        ctx.window_manager.event_timer_remove(mocap_timer)
        is_connected = False
        ctx.scene.msm_connected= False
        self.report({"INFO"}, "Disconnected.")
        print(f"MocapDisconnect 1")
        stop_event.set()
        if network_thread:
            network_thread.join()
        actor_mgr.Clear()
        ctx.scene.msm_actor_count = 0
        ctx.scene.msm_actor_source_ids = "NONE"
        print(f"MocapDisconnect 2")
        # ctx.scene.msm_new_target = "NONE"
        arms = [a for a in bpy.data.armatures]
        for a in arms:
            bpy.data.armatures.remove(a)
        ctx.scene.target_items.clear()
        ctx.scene.target_items_enums="NONE"
        received_messages = None
        stop_event.clear()
        print(f"MocapDisconnect 3")
        return {"FINISHED"}

# Icon Button Operator
class MocapPlayButtonOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_play"
    bl_label = "同步"

    def execute(self, ctx):
        global actor_mgr
        self.report({'INFO'}, "同步 Button Clicked!")
        ctx.scene.msm_playing= True
        actor_mgr.LiveSync(True)
        return {'FINISHED'}
    
# Icon Button Operator
class MocapPauseButtonOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_pause"
    bl_label = "暂停"

    def execute(self, ctx):
        self.report({'INFO'}, "暂停 Button Clicked!")
        ctx.scene.msm_playing= False
        actor_mgr.LiveSync(False)
        return {'FINISHED'}
  
# Icon Button Operator
class MocapRecordButtonOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_record"
    bl_label = "录制"

    def execute(self, ctx):
        global actor_mgr
        if ctx.scene.msm_playing:
            self.report({'INFO'}, "录制 Button Clicked!")
            actor_mgr.StartRec()
            ctx.scene.msm_recording = True
        return {'FINISHED'}
    
# Icon Button Operator
class MocapStopButtonOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_stop"
    bl_label = "结束"

    def execute(self, ctx):
        global actor_mgr
        if ctx.scene.msm_playing:
            self.report({'INFO'}, "结束 Button Clicked!")
            actor_mgr.StopRec()
            ctx.scene.msm_recording = False
        return {'FINISHED'}

