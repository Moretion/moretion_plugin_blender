from bpy.utils import previews

class MSSettings:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            print("Create MSSettings")
            cls._instance = super().__new__(cls, *args, **kwargs)
            cls._instance.pcoll = previews.new()
            cls._instance.preview_collections = {}
            cls._instance.cur_Version = '0.0.1'
            cls._instance.MS_Version = '1.8.60'
        return cls._instance
    
    def add_preview(self,name,path):
        self.pcoll.load(name, path, 'IMAGE')
        self.preview_collections["main"] = self.pcoll

    def get_icon_id(self,name):
        return self.pcoll[name].icon_id
    
    def clear_preview(self):
        for pcoll in self.preview_collections.values():
            previews.remove(pcoll)
        self.preview_collections.clear()