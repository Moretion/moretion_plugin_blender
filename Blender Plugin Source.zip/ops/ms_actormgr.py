import bpy
# from ..mocap_api.msnetwork import *
from ..ops.ms_connection import ActorMgr

def ActorShowHide(context,index):
    actor_mgr = ActorMgr()
    if getattr(context.scene,f'msm_actor_vis_{index+1}'):
        actor_mgr.actors[index].SetVisible(False)
        setattr(context.scene,f'msm_actor_vis_{index+1}',False)
    else:
        setattr(context.scene,f'msm_actor_vis_{index+1}',True)
        actor_mgr.actors[index].SetVisible(True)
    
def ActorPose(context,index):
    actor_mgr = ActorMgr()
    if getattr(context.scene,f'msm_actor_pose_{index+1}'):
        setattr(context.scene,f'msm_actor_pose_{index+1}',False)
        actor_mgr.actors[index].SetTPose(True)
    else:
        setattr(context.scene,f'msm_actor_pose_{index+1}',True)
        actor_mgr.actors[index].SetTPose(False)

class MocapActorNameBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_actorname"
    bl_label = "角色名称"
    
    def execute(self, context):
        context.scene.msm_show_actor_name = not context.scene.msm_show_actor_name        
        self.bl_label = "角色名称" if context.scene.msm_show_actor_name else "角色ID"
        self.report({'INFO'}, "角色名称 Clicked!")
        return {'FINISHED'}

class MocapActorsVisibleOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_actorvis_all"
    bl_label = "角色显示隐藏"
    def execute(self, context):
        context.scene.msm_actor_visible = not context.scene.msm_actor_visible
        for i in range(context.scene.msm_actor_count): 
            setattr(context.scene,f'msm_actor_vis_{i+1}',not context.scene.msm_actor_visible)
            ActorShowHide(context,i)
        self.report({'INFO'}, "角色显示隐藏 Clicked!")
        return {'FINISHED'}

class MocapActorsRetargetOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_actorretarget_all"
    bl_label = "重定向"

    def execute(self, ctx):
        global actor_mgr
        self.report({'INFO'}, "重定向 Button Clicked!")
        ctx.scene.msm_actor_pose = not ctx.scene.msm_actor_pose
        return {'FINISHED'}


class MocapActorVisBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_actorvis"
    bl_label = "显示"
    
    click_index : bpy.props.IntProperty()

    def execute(self, context):
        ActorShowHide(context,self.click_index)
        return {'FINISHED'}
    
class MocapActorsPoseOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_actorpose_all"
    bl_label = "角色姿态"
    def execute(self, context):
        context.scene.msm_actor_pose = not context.scene.msm_actor_pose
        for i in range(context.scene.msm_actor_count): 
            setattr(context.scene,f'msm_actor_pose_{i+1}', not context.scene.msm_actor_pose)
            ActorPose(context,i)
        self.report({'INFO'}, "切换角色姿态 Clicked!")
        return {'FINISHED'}

class MocapActorPoseBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.btn_actorpose"
    bl_label = "姿态"
    
    click_index : bpy.props.IntProperty()

    def execute(self, context):
        ActorPose(context,self.click_index)
        return {'FINISHED'}

