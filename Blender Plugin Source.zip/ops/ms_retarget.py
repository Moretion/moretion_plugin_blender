import bpy
from .ms_connection import ActorMgr
actormgr = ActorMgr()

class MocapUpdateTargetBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.update_target_object"
    bl_label = "新增/删除目标角色"

    action_add : bpy.props.BoolProperty()

    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE" and context.scene.msm_new_target != "NONE"

    def execute(self, context):
        if self.action_add:
            bl_label = "新增目标角色"
            print(f"add Target: {context.scene.msm_new_target} to Source {context.scene.msm_actor_source_ids}")
        else:
            bl_label = "删除目标角色"
            print(f"Remove Target: {context.scene.target_items_enums} from Source {context.scene.msm_actor_source_ids}")
            
        for obj in bpy.data.objects:
            if self.action_add:
                if obj.name == context.scene.msm_new_target:
                    actormgr.AddRetargetToActor(context.scene.msm_actor_source_ids,obj)
                    break
            else:
                if obj.name == context.scene.target_items_enums:
                    actormgr.RemoveRetargetFromActor(context.scene.msm_actor_source_ids,obj)
                    break
        bpy.context.scene.target_items.clear()
        actormgr.RefreshRetargetEnumList()
        # bpy.context.scene.target_items_enums.clear()
        ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
        if ac:
            for n in ac.GetRetargetList():
                item = bpy.context.scene.target_items.add()
                item.name = n
            bpy.context.scene.bones_remap.clear()
            remaplist = ac.GetRemapList(context.scene.target_items_enums)
            for index,i in enumerate(ac.bones):
                remapitem = bpy.context.scene.bones_remap.add()
                remapitem.source_bone = i.name.replace(f'MS_{ac.deviceId}_','')
                if remaplist and remaplist['remap'][index]:
                    remapitem.name = remaplist['remap'][index].name
                else:
                    remapitem.name = "None"
                # print(f"{index} T:{remapitem.name} S:{remapitem.source_bone}")
        return {'FINISHED'}

class MS_UL_Target_List(bpy.types.UIList):
    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop_enum(data,"target_items_enums",item.name)
        # layout.operator("ms_mocap.select_target",text=item.name,depress=CheckSelect(item.name)).actor_id = item.name
        
    def invoke(self, context, event):
        self.draw_item()


class MocapBuildRemapListBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.build_remap"
    bl_label = "建立骨骼映射表"

    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE" and context.scene.target_items_enums != "NONE"

    def execute(self, context):
        print(f"Click Build Remap: Source {context.scene.msm_actor_source_ids} Target {context.scene.target_items_enums}")
        ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
        if ac:
            ac.BuildNewRemapList(context.scene.target_items_enums)
            remaplist = ac.GetRemapList(context.scene.target_items_enums)
            bpy.context.scene.bones_remap.clear()
            for index,i in enumerate(ac.bones):
                
                item = bpy.context.scene.bones_remap.add()
                item.source_bone = i.name.replace(f'MS_{ac.deviceId}_','')
                if remaplist and remaplist['remap'][index]:
                    item.name = remaplist['remap'][index].name
                else:
                    item.name = "None"
        return {'FINISHED'}


class MS_UL_Remap_Items(bpy.types.UIList):
    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        split = layout.split(factor=1.0)
        split.prop(item, "source_bone", text="",emboss=False, translate=False)
        split = layout.split(factor=1.0)
        split.prop(item, "name", text="",emboss=False, translate=False)

    def invoke(self, context, event):
        self.draw_item()


class MS_UL_Remap_Sheet(bpy.types.UIList):
    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pass
        # ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
        # if ac :
        #     remaplist = ac.GetRemapList(context.scene.target_items_enums)
        #     if remaplist:
        #         # split.prop_search(context.scene, "remap_items_enums", bpy.data.armatures, "objects", text='')
        #         # split.prop(context.scene, "remap_items_enums",text='')

        #         # split.label(text=f'{remaplist["remap"][index].name if remaplist["remap"][index] else ""}')
        #         split.operator('ms_mocap.remap_item_update',emboss=False,text=f'{remaplist["remap"][index].name if remaplist["remap"][index] else "None"}').item_index = index
        # else:
        #     # split.label(text='None')
        #     split.operator('ms_mocap.remap_item_update',emboss=False,text='None').item_index = index
            # split.prop_search(context.scene, "remap_items_enums", bpy.data.armatures, "objects", text='')
            # split.prop(context.scene, "remap_items_enums",text='')
    def invoke(self, context, event):
        self.draw_item()


class MocapRemapUpdateBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.remap_item_update"
    bl_label = "选择骨骼映射"

    item_index : bpy.props.IntProperty()

    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE" and context.scene.target_items_enums != "NONE"

    def execute(self, context):
        print(f"Click Change Remap: Source {context.scene.msm_actor_source_ids} Target {self.item_index}")
        
        return {'FINISHED'}

class MocapRetargetRemapBtnOperator(bpy.types.Operator):
    bl_idname = "ms_mocap.retarget_remap"
    bl_label = "保存骨骼映射表"

    @classmethod
    def poll(cls, context):
        return context.scene.msm_actor_source_ids != "NONE" and context.scene.target_items_enums != "NONE"

    def execute(self, context):
        print(f"Click Save Remap: Source {context.scene.msm_actor_source_ids} Target {context.scene.target_items_enums}")
        ac = actormgr.GetActor(bpy.context.scene.msm_actor_source_ids)
        if ac:
            ac.SaveAndEnableRemapList(context.scene.target_items_enums,context.scene.bones_remap)

        return {'FINISHED'}
